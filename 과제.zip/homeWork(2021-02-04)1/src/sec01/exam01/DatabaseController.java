package sec01.exam01;

import java.sql.Array;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.concurrent.Semaphore;

public class DatabaseController {
	
	//�������
	public static boolean deleteQueryNo(String phone) throws Exception{
		
		boolean flag = false;
		
		Connection connection = DBUtil.getConnection();
		
		String deleteQuery = "delete from phoneinfo where phone = ? ";
		PreparedStatement preparedStatement = null;
		
		try {
			preparedStatement = connection.prepareStatement(deleteQuery);
			
			preparedStatement.setString(1, phone);
			
			int count = preparedStatement.executeUpdate();
			if(count == 1) {
				System.out.println("��������");
				flag = true;
			}else {
				System.out.println("��������");
			}
			
		}catch (Exception e) {
			System.out.println("�����ͺ��̽� �����κп��� ������ �߻��߽��ϴ�.");
		}finally {
			if(preparedStatement != null) {
				preparedStatement.close();
			}
			if(preparedStatement != null) {
				connection.close();
			}
		}//end of finally
		
		return flag;
	}
	
	//�����ϴ� ���
	public static boolean insertQueryPhoneif(PhoneInfo ss) throws Exception{
		
		boolean flag = false;
		
		//System.out.println(ss.toString());
		Connection connection = DBUtil.getConnection();
		String insertQuery = "insert into phoneinfo values(?, ?, ?, ?, ?, ?)";
		
		PreparedStatement preparedStatement = null;
		
		try {
			connection.prepareStatement(insertQuery);
			
			preparedStatement = connection.prepareStatement(insertQuery);
			preparedStatement.setString(1, ss.getPhoneNumber());
			preparedStatement.setString(2, ss.getName());
			preparedStatement.setString(3, ss.getGender());
			preparedStatement.setString(4, ss.getBirthday());
			preparedStatement.setInt(5, ss.getAge());
			preparedStatement.setString(6, ss.getDate());
			
			int count = preparedStatement.executeUpdate();
			
			if(count != 0) {
				System.out.println(ss.getName() + "�� �Է� ����");
				flag = true;
			}else {
				System.out.println(ss.getName() + "�� �Է� ����");
			}			
		}catch (Exception e) {
			System.out.println("�Է��ϴµ� ������ �߻��߽��ϴ�.");
			e.printStackTrace();
			
		}finally {
			if(preparedStatement != null) {
				preparedStatement.close();
			}
			if(connection != null) {
				preparedStatement.close();
			}
		}
		return flag;	
	}
	
	//����ϴ� ���
	public static HashSet<PhoneInfo> selectQueryPhoneInfoTotal() throws Exception{
		HashSet<PhoneInfo> hashSet = new HashSet<PhoneInfo>();
		Connection connection = DBUtil.getConnection();
		PreparedStatement preparedStatement = null;
		String selectQuery = "select * from phoneinfo";
		
		preparedStatement = connection.prepareStatement(selectQuery);
		ResultSet resultSet = preparedStatement.executeQuery();
		
		try {
			while(resultSet.next()) {
				String phoneNumber = resultSet.getString(1);
				String name = resultSet.getString(2);
				String gender = resultSet.getString(3);
				String birthday = resultSet.getString(4);
				int age = resultSet.getInt(5);
				String date = resultSet.getString(6);
				
				PhoneInfo phoneInfo = new PhoneInfo(phoneNumber, name, gender, birthday, age, date);
				hashSet.add(phoneInfo);
			}
		}catch (Exception e) {
			System.out.println("select query error " + e.toString());
		}finally {
			if(preparedStatement != null) {
				preparedStatement.close();
			}
			if(connection != null) {
				preparedStatement.close();
			}
		}
		return hashSet;
	} 
	
	//��ȣ�˻� ���
	public static PhoneInfo selectQueryPhoneInfoWhereNo(String phone) throws Exception{
		PhoneInfo phoneInfo = null;
		Connection connection = DBUtil.getConnection();
		PreparedStatement preparedStatement = null;
		String selectQuery = "select * from phoneinfo where phone = ? ";
		
		try {
			preparedStatement = connection.prepareStatement(selectQuery);
			preparedStatement.setString(1, phone);
			ResultSet resultSet = preparedStatement.executeQuery();
			
			while(resultSet.next()) {
				String phoneNumber = resultSet.getString(1);
				String name = resultSet.getString(2);
				String gender = resultSet.getString(3);
				String birthday = resultSet.getString(4);
				int age = resultSet.getInt(5);
				String data = resultSet.getString(6);
				
				phoneInfo = new PhoneInfo(phoneNumber, name, birthday, gender, age, data);
			}	
		}catch (Exception e) {
			System.out.println("select query where phone error " + e.toString());
		}finally {
			if(preparedStatement != null) {
				preparedStatement.close();
			}
			if(connection != null) {
				preparedStatement.close();
			}
		}
		return phoneInfo;		
	}
	
	//�̸��˻��ϴ� ���
	public static HashSet<PhoneInfo> selectQueryPhoneInfoName(String searchName) throws Exception{
		HashSet<PhoneInfo> hashSet = new HashSet<PhoneInfo>();
		Connection connection = DBUtil.getConnection();
		PreparedStatement preparedStatement = null;
		searchName = "%" + searchName + "%";
		String selectQurey = "select * from phoneinfo where name like ?";
		
		try {
			preparedStatement = connection.prepareStatement(selectQurey);
			preparedStatement.setString(1, searchName);
			ResultSet resultSet = preparedStatement.executeQuery();
			
			while(resultSet.next()) {
				String phoneNumber = resultSet.getString(1);
				String name = resultSet.getString(2);
				String gender = resultSet.getString(3);
				String birthday = resultSet.getString(4);
				int age = resultSet.getInt(5);
				String data = resultSet.getString(6);
				
				PhoneInfo phoneInfo = new PhoneInfo(phoneNumber, name, birthday, gender, age, data);
				hashSet.add(phoneInfo);
			}
			
		}catch (Exception e) {
			System.out.println("select query where name error " + e.toString());
		}finally {
			if(preparedStatement != null) {
				preparedStatement.close();
			}
			if(connection != null) {
				preparedStatement.close();
			}
		}
		
		return hashSet;
	}
	
	//�������� ���������ϴ� ���
	public static ArrayList<PhoneInfo> orderByTotalPhoneInfo(int selectDescAsc) throws Exception{
		
		ArrayList<PhoneInfo> arrayList = new ArrayList<PhoneInfo>();
		Connection connection = DBUtil.getConnection();
		PreparedStatement preparedStatement = null;
		String selectQury = null;
		
		if(selectDescAsc == 1) {
			selectQury = "select * from phoneinfo order by phone desc";
		}else {
			selectQury = "select * from phoneinfo order by phone asc";
		}
		
		try {
			preparedStatement = connection.prepareStatement(selectQury);
			ResultSet resultSet = preparedStatement.executeQuery();
			
			while(resultSet.next()) {
				String phoneNumber = resultSet.getString(1);
				String name = resultSet.getString(2);
				String gender = resultSet.getString(3);
				String birthday = resultSet.getString(4);
				int age = resultSet.getInt(5);
				String date = resultSet.getString(6);
				
				PhoneInfo phoneInfo = new PhoneInfo(phoneNumber, name, birthday, gender, age, date);
				arrayList.add(phoneInfo);
			}
		}catch (Exception e) {
			System.out.println("select query order by total error " + e.toString());
		}finally {
			if(preparedStatement != null) {
				preparedStatement.close();
			}
			if(connection != null) {
				preparedStatement.close();
			}
		}
		return arrayList;
	}
	
	//�����ϴ� ���
	public static boolean updatQuerPhoneInfo(PhoneInfo ss) throws Exception {
		
		boolean flag = false;
		//2. �ش�Ǵ� ��ü�� ������ �����ͺ��̽��� ������ �����Ѵ�.
    	Connection connection = DBUtil.getConnection();
    	String updateQuery = "update phoneinfo set name = ?, age = ? where phone = ?";
    		    	
    	PreparedStatement preparedStatement = null;
    	//db�� �׻� try���ش�
    	try {
    		connection.prepareStatement(updateQuery);
    		//db���ٰ� ����ִ°Ŵ�.
    		preparedStatement = connection.prepareStatement(updateQuery);
    		
    		preparedStatement.setString(1, ss.getName());
    		preparedStatement.setInt(2, ss.getAge());
    		preparedStatement.setString(3, ss.getPhoneNumber());
    		
    		
    		int count = preparedStatement.executeUpdate();
    		
    		if(count != 0) {
    			System.out.println(ss.getName() + "�� ���� ����");
    			flag = true;
    		}else {
    			System.out.println(ss.getName() + "�� ���� ����");    		
    		}
    		
    	}catch (Exception e) {
			System.out.println("�����ϴµ� ������ �߻��߽��ϴ�.");
			e.printStackTrace();
		}finally {
			if(preparedStatement != null) {
				preparedStatement.close();
			}
			if(connection != null) {
				preparedStatement.close();
			}
		}
		return flag;
	}
}
